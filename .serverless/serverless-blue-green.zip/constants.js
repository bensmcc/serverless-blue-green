"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
exports.version = '1.1.1';
//# sourceMappingURL=constants.js.map